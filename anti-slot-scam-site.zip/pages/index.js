import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { BadgeAlert, Search, UploadCloud, Share2 } from "lucide-react";

export default function HomePage() {
  const shareToLine = () => {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent("ระวัง! เว็บสล็อตโกง ล็อกยูส ถอนเงินไม่ได้ — ตรวจสอบรายชื่อที่นี่!");
    window.open(`https://social-plugins.line.me/lineit/share?url=${url}&text=${text}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-red-50 to-slate-100 p-4 md:p-6 space-y-10">
      <header className="text-center">
        <h1 className="text-3xl md:text-4xl font-bold text-[#D4AF37] drop-shadow-sm mb-2">Blacklist เว็บสล็อตโกง</h1>
        <p className="text-sm md:text-base text-gray-700">รวมข้อมูลเว็บโกง ล็อกยูส ไม่จ่ายจริง – เพื่อปกป้องนักเล่นทุกคน</p>
      </header>

      <div className="text-center">
        <Button variant="outline" className="border-green-500 text-green-600 hover:bg-green-100" onClick={shareToLine}>
          <Share2 className="h-4 w-4 mr-2" /> แชร์ผ่าน LINE
        </Button>
      </div>

      <section className="max-w-xl mx-auto px-2">
        <div className="flex flex-col sm:flex-row gap-2">
          <Input placeholder="พิมพ์ชื่อเว็บที่ต้องการตรวจสอบ..." className="flex-1 bg-white border border-[#B87333]" />
          <Button variant="destructive" className="w-full sm:w-auto bg-gradient-to-r from-red-600 to-[#B87333] hover:opacity-90">
            <Search className="h-4 w-4 mr-2" /> ค้นหา
          </Button>
        </div>
      </section>

      <section className="px-2">
        <h2 className="text-xl md:text-2xl font-semibold text-[#C0C0C0] mb-4">เว็บโกงล่าสุด</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { name: "XYZBET123", status: "ล็อกยูส ถอนเงินไม่ได้" },
            { name: "FASTWIN88", status: "ระบบหลอกแตกปลอม" },
            { name: "PGBRO999", status: "ไม่จ่าย ถอนแล้วเงียบ" },
          ].map((site, idx) => (
            <Card key={idx} className="border-2 border-[#B87333] bg-gradient-to-tl from-white to-yellow-50 shadow-md">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <BadgeAlert className="text-red-600" />
                  <h3 className="text-lg font-bold text-red-700">{site.name}</h3>
                </div>
                <p className="text-sm text-gray-700 mt-1">{site.status}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="bg-gradient-to-br from-white via-slate-50 to-yellow-100 p-4 md:p-6 rounded-xl shadow-md max-w-2xl mx-auto px-2 border border-[#D4AF37]">
        <h2 className="text-lg md:text-xl font-bold text-[#B87333] mb-4">แจ้งเว็บโกงเพิ่มเติม</h2>
        <form className="space-y-4">
          <Input placeholder="ชื่อเว็บไซต์ (เช่น ABC123.com)" required className="bg-white border border-[#D4AF37]" />
          <Textarea placeholder="รายละเอียดการโกง เช่น ถอนเงินไม่ได้ โดนล็อกยูส ฯลฯ" required className="bg-white border border-[#B87333]" />
          <Input type="file" className="cursor-pointer border border-[#C0C0C0] bg-white" />
          <Button type="submit" className="w-full md:w-auto bg-gradient-to-r from-[#D4AF37] via-red-500 to-[#C0C0C0] text-white hover:opacity-90">
            <UploadCloud className="h-4 w-4 mr-2" /> ส่งข้อมูล
          </Button>
        </form>
      </section>
    </div>
  );
}